#include "mainwindow.h"
#include "move_pacman.h"
#include "move_ghost1.h"
#include "move_baby.h"
#include "ui_mainwindow.h"
#include "QtMath"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setFixedSize(1100,900);
    this->setWindowTitle("Pacman");

    Start_Game=new QPushButton("start game",this);
    Start_Game->setGeometry(900,400,200,40);
    //Start_Game->setFlat(1);


    myLCDNumber = new QLCDNumber(this);
    myLCDNumber->setGeometry(900,100,200,80);
    myLCDNumber->setDigitCount(3);

    myTimer = new QTimer(this);
    myTimer->start(30);
    showTime();

    connect(myTimer,SIGNAL(timeout()),this,SLOT(showTime()));
    connect(Start_Game,SIGNAL(clicked(bool)),this,SLOT(Start_Game_Slots()));



}

void MainWindow::ghost_turn(int a ,int b)
{
    if(b==1)//up
    {
       ghost[a][3] = -1;
       ghost[a][2] = 0;
    }
    else if(b==2)//down
    {
        ghost[a][3] = 1;
        ghost[a][2] = 0;
    }
    else if(b==3)//left
    {
        ghost[a][2] = -1;
        ghost[a][3] = 0;
    }
    else if(b==4)//right
    {
        ghost[a][2] = 1;
        ghost[a][3] = 0;
    }
}

void MainWindow::turn_mode(int a,int b)
{
    switch(a)
    {
     case 1://onle up
        canturn[b][0]=1;
        break;
     case 2://only down
        canturn[b][1]=1;
        break;
     case 3://only left
        canturn[b][2]=1;
        break;
     case 4://only right
        canturn[b][3]=1;
        break;
     case 5://up down
        canturn[b][0]=1;
        canturn[b][1]=1;
        break;
     case 6://left right
        canturn[b][2]=1;
        canturn[b][3]=1;
        break;
     case 7://up right
        canturn[b][0]=1;
        canturn[b][3]=1;
        break;
     case 8://up left
       canturn[b][0]=1;
       canturn[b][2]=1;
       break;
     case 9://right down
       canturn[b][1]=1;
       canturn[b][3]=1;
       break;
     case 10://left down
       canturn[b][1]=1;
       canturn[b][2]=1;
       break;
    case 11://up can not
      canturn[b][1]=1;
      canturn[b][2]=1;
      canturn[b][3]=1;
      break;
    case 12://down can not
      canturn[b][0]=1;
      canturn[b][2]=1;
      canturn[b][3]=1;
      break;
    case 13://left can not
      canturn[b][0]=1;
      canturn[b][1]=1;
      canturn[b][3]=1;
      break;
    case 14://right can not
        canturn[b][0]=1;
        canturn[b][2]=1;
        canturn[b][1]=1;
        break;
     default:
        for(int i=0;i<4;i++)
        {
            canturn[b][i]=1;
        }
    }
}

void MainWindow::control_ghost1()
{
    int turning = 0;
    if(pacman[0] > ghost[0][0] )
    {
        if(pacman[1] > ghost[0][1]) turning=4;
        else if(pacman[1] < ghost[0][1]) turning=1;
        else if(pacman[1] == ghost[0][1]) turning=8;
    }
    else if(pacman[0] < ghost[0][0] )
    {
        if(pacman[1] > ghost[0][1]) turning=3;
        else if(pacman[1] < ghost[0][1]) turning=2;
        else if(pacman[1] == ghost[0][1]) turning=6;
    }
    else if(pacman[0] == ghost[0][0])
    {
        if(pacman[1] > ghost[0][1]) turning=7;
        else  turning=5;
        //else if(pacman[1] == ghost[0][1])
    }
    if(god == 0)
    {
        switch(turning)
        {
        case 1:
            if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            break;
        case 2:
            if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            break;
        case 3:
            if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            break;
        case 4:
            if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            break;
        case 5:
            if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            else if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            break;
        case 6:
            if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            break;
        case 7:
            if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            else if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            break;
        default:
            if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            break;
        }
    }
    else {
        switch(turning)
        {
        case 2:
            if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            break;
        case 1:
            if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            break;
        case 4:
            if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            break;
        case 3:
            if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            break;
        case 7:
            if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            else if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            break;
        case 8:
            if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            break;
        case 5:
            if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            else if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            break;
        default:
            if(canturn[1][3] == 1) ghost_turn(0 ,4);//right
            else if(canturn[1][1] == 1) ghost_turn(0 ,2);//down
            else if(canturn[1][0] == 1) ghost_turn(0 ,1);//up
            else if(canturn[1][2] == 1) ghost_turn(0 ,3);//left
            break;
        }
    }


}

void MainWindow::control_ghost2()
{
    int turning = 0;
    if(pacman[0] + 4* pacman[2] >   ghost[1][0] )
    {
        if(pacman[1]+ 4* pacman[3] >   ghost[1][1]) turning=4;
        else if(pacman[1]+ 4* pacman[3] <   ghost[1][1]) turning=1;
        else if(pacman[1]+ 4* pacman[3] ==   ghost[1][1]) turning=8;
    }
    else if(pacman[0]+ 4* pacman[2] <   ghost[1][0] )
    {
        if(pacman[1]+ 4* pacman[3] >   ghost[1][1]) turning=3;
        else if(pacman[1]+ 4* pacman[3] <   ghost[1][1]) turning=2;
        else if(pacman[1]+ 4* pacman[3] ==   ghost[1][1]) turning=6;
    }
    else if(pacman[0]+ 4* pacman[2] ==   ghost[1][0])
    {
        if(pacman[1]+ 4* pacman[3] >   ghost[1][1]) turning=7;
        else  turning=5;
        //else if(pacman[1] ==   ghost[1][1])
    }
    if(block_timer < 150){
      if(ghost[1][0] < 280) turning=1;
      else if(ghost[1][0] == 695) turning=2;
    }
    if(god == 0)
    {
            switch(turning)
            {
            case 1:
                if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                break;
            case 2:
                if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                break;
            case 3:
                if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                break;
            case 4:
                if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                break;
            case 5:
                if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                else if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                break;
            case 6:
                if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                break;
            case 7:
                if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                else if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                break;
            default:
                if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                break;
            }
        }
    else {
            switch(turning)
            {
            case 2:
                if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                break;
            case 1:
                if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                break;
            case 4:
                if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                break;
            case 3:
                if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                break;
            case 7:
                if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                else if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                break;
            case 8:
                if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                break;
            case 5:
                if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                else if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                break;
            default:
                if(canturn[2][3] == 1) ghost_turn(1 ,4);//right
                else if(canturn[2][1] == 1) ghost_turn(1 ,2);//down
                else if(canturn[2][0] == 1) ghost_turn(1 ,1);//up
                else if(canturn[2][2] == 1) ghost_turn(1 ,3);//left
                break;
            }
        }

}






void MainWindow::control_ghost3()
{
    int turning = 0;
    int k;
    int a = pacman[0]- ghost[0][0];
    int b = pacman[1]- ghost[0][1];
    k = sqrt(a*a+b*b);

    if(pacman[0]+ k* pacman[2] >   ghost[2][0] )
    {
        if(pacman[1]+ k* pacman[3] >   ghost[2][1]) turning=4;
        else if(pacman[1]+ k* pacman[3] <   ghost[2][1]) turning=1;
        else if(pacman[1]+ k* pacman[3] ==   ghost[2][1]) turning=8;
    }
    else if(pacman[0]+ k* pacman[2] <   ghost[2][0] )
    {
        if(pacman[1]+ k* pacman[3] >   ghost[2][1]) turning=3;
        else if(pacman[1]+ k* pacman[3] <   ghost[2][1]) turning=2;
        else if(pacman[1]+ k* pacman[3] ==   ghost[2][1]) turning=6;
    }
    else if(pacman[0]+ k* pacman[2] ==   ghost[2][0])
    {
        if(pacman[1]+ k* pacman[3] >   ghost[2][1]) turning=7;
        else  turning=5;
        //else if(pacman[1] ==   ghost[2][1])
    }

    if(block_timer < 225){
      if(ghost[1][0] < 280) turning=1;
      else if(ghost[1][0] == 695) turning=2;
    }

    if(god == 0)
    {
        switch(turning)
        {
        case 1:
            if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            break;
        case 2:
            if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            break;
        case 3:
            if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            break;
        case 4:
            if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            break;
        case 5:
            if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            else if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            break;
        case 6:
            if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            break;
        case 7:
            if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            else if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            break;
        default:
            if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            break;
        }
    }
    else {
        switch(turning)
        {
        case 2:
            if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            break;
        case 1:
            if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            break;
        case 4:
            if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            break;
        case 3:
            if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            break;
        case 7:
            if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            else if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            break;
        case 8:
            if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            break;
        case 5:
            if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            else if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            break;
        default:
            if(canturn[3][3] == 1) ghost_turn(2 ,4);//right
            else if(canturn[3][1] == 1) ghost_turn(2 ,2);//down
            else if(canturn[3][0] == 1) ghost_turn(2 ,1);//up
            else if(canturn[3][2] == 1) ghost_turn(2 ,3);//left
            break;
        }
    }
}


void MainWindow::control_ghost4()
{
    int turning = 0;
    int k;
    int a = pacman[0]- ghost[3][0];
    int b = pacman[1]- ghost[3][1];
    k = sqrt(a*a+b*b);

    if(pacman[0] >   ghost[3][0] )
    {
        if(pacman[1] >   ghost[3][1]) turning=4;
        else if(pacman[1] <   ghost[3][1]) turning=1;
        else if(pacman[1] ==   ghost[3][1]) turning=8;
    }
    else if(pacman[0] <   ghost[3][0] )
    {
        if(pacman[1] >   ghost[3][1]) turning=3;
        else if(pacman[1] <   ghost[3][1]) turning=2;
        else if(pacman[1] ==   ghost[3][1]) turning=6;
    }
    else if(pacman[0] ==   ghost[3][0])
    {
        if(pacman[1] >   ghost[3][1]) turning=7;
        else  turning=5;
        //else if(pacman[1] ==   ghost[3][1])
    }

    if(block_timer < 300){
      if(ghost[1][0] < 280) turning=1;
      else if(ghost[1][0] == 695) turning=2;
    }

    switch(turning)
    {
    case 1:
        if(canturn[4][3] == 1) ghost_turn(3 ,4);//right
        else if(canturn[4][1] == 1) ghost_turn(3 ,2);//down
        else if(canturn[4][0] == 1) ghost_turn(3 ,1);//up
        else if(canturn[4][2] == 1) ghost_turn(3 ,3);//left
        break;
    case 2:
        if(canturn[4][2] == 1) ghost_turn(3 ,3);//left
        else if(canturn[4][1] == 1) ghost_turn(3 ,2);//down
        else if(canturn[4][0] == 1) ghost_turn(3 ,1);//up
        else if(canturn[4][3] == 1) ghost_turn(3 ,4);//right
        break;
    case 3:
        if(canturn[4][2] == 1) ghost_turn(3 ,3);//left
        else if(canturn[4][1] == 1) ghost_turn(3 ,2);//down
        else if(canturn[4][0] == 1) ghost_turn(3 ,1);//up
        else if(canturn[4][3] == 1) ghost_turn(3 ,4);//right
        break;
    case 4:
        if(canturn[4][3] == 1) ghost_turn(3 ,4);//right
        else if(canturn[4][1] == 1) ghost_turn(3 ,2);//down
        else if(canturn[4][0] == 1) ghost_turn(3 ,1);//up
        else if(canturn[4][2] == 1) ghost_turn(3 ,3);//left
        break;
    case 5:
        if(canturn[4][0] == 1) ghost_turn(3 ,1);//up
        else if(canturn[4][3] == 1) ghost_turn(3 ,4);//right
        else if(canturn[4][2] == 1) ghost_turn(3 ,3);//left
        else if(canturn[4][1] == 1) ghost_turn(3 ,2);//down
        break;
    case 6:
        if(canturn[4][2] == 1) ghost_turn(3 ,3);//left
        else if(canturn[4][1] == 1) ghost_turn(3 ,2);//down
        else if(canturn[4][0] == 1) ghost_turn(3 ,1);//up
        else if(canturn[4][3] == 1) ghost_turn(3 ,4);//right
        break;
    case 7:
        if(canturn[4][1] == 1) ghost_turn(3 ,2);//down
        else if(canturn[4][3] == 1) ghost_turn(3 ,4);//right
        else if(canturn[4][2] == 1) ghost_turn(3 ,3);//left
        else if(canturn[4][0] == 1) ghost_turn(3 ,1);//up
        break;
    default:
        if(canturn[4][3] == 1) ghost_turn(3 ,4);//right
        else if(canturn[4][1] == 1) ghost_turn(3 ,2);//down
        else if(canturn[4][0] == 1) ghost_turn(3 ,1);//up
        else if(canturn[4][2] == 1) ghost_turn(3 ,3);//left
        break;
    }

    if(k <= 300)
    {
        re[0] = 1;
    }

    if(ghost[3][0] == 0 && ghost[3][1] == 0 )
    {
        re[0] = 0;
    }

    if(re[0] == 1)
    {
        if(canturn[4][2] == 1) ghost_turn(3 ,3);//left
        else if(canturn[4][0] == 1) ghost_turn(3 ,1);//up
        else if(canturn[4][3] == 1) ghost_turn(3 ,4);//right
        else if(canturn[4][1] == 1) ghost_turn(3 ,2);//down
    }

}


void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if(event->key()==Qt::Key_W && canturn[0][0]==1)
    {
        pacman[3]= -1;
        pacman[2]= 0;
    }
    if(event->key()==Qt::Key_S && canturn[0][1]==1)
    {
        pacman[3]= 1;
        pacman[2]= 0;
    }
    if(event->key()==Qt::Key_A && canturn[0][2]==1)
    {
        pacman[2]= -1;
        pacman[3]= 0;
    }
    if(event->key()==Qt::Key_D && canturn[0][3]==1)
    {
        pacman[2]= 1;
        pacman[3]= 0;
    }
}

void MainWindow::map(/*double a,double b,int c,int d*/)
{
    for(int i=0;i<13;i++){
        for(int j=0;j<13;j++)
           {
            point_small[i][j] = 0;
           }
    }



    for(int i=0;i<13;i++)
        for(int j=0;j<13;j++)
           point_small[i][j] = 1;
    for(int i=2;i<9;i++)
        point_small[2][i] = 0;
    for(int i=2;i<11;i++)
        point_small[i][2] = 0;

    for(int i=10;i>1;i--)
        point_small[i][10] = 0;
    for(int i=10;i>3;i--)
        point_small[10][i] = 0;
    for(int i=4;i<9;i++)
        point_small[i][4] = 0;
    for(int i=4;i<9;i++)
        for(int j=6;j<9;j++)
           point_small[i][j] = 0;

    point_small[0][9] = 2;
    point_small[12][3] = 2;
    point_small[9][7] = 2;
    point_small[3][4] = 2;
    point_small[3][7] = 2;
    point_small[9][4] = 2;
}

void MainWindow::map_ghost0()
{

}

void MainWindow::eat_point()
{

    for(int i=0;i<13;i++)
    {
        for(int j=0;j<13;j++)
        {
            if(pacman[0] == 70*i && pacman[1] == 70*j)
            {
                if(point_small[i][j] == 1)
                {
                    score = score +10;
                    point_how_many++;
                    point_small[i][j] = 0;
                }
                else if(point_small[i][j] == 2)
                {
                    score = score +20;
                    god=1;
                    point_how_many++;
                    point_small[i][j] = 0;
                }
            }
        }
    }
}

void MainWindow::eat_ghost()
{
    if(pacman[0] == ghost[0][0] && pacman[1] == ghost[0][1])
    {
        score=score+10;
        ghost_died[0]=1;
    }
    if(pacman[0] == ghost[1][0] && pacman[1] == ghost[1][1])
    {
        score=score+10;
        ghost_died[1]=1;
    }
    if(pacman[0] == ghost[2][0] && pacman[1] == ghost[2][1])
    {
        score=score+10;
        ghost_died[2]=1;
    }
    if(pacman[0] == ghost[3][0] && pacman[1] == ghost[3][1])
    {
        score=score+10;
        ghost_died[3]=1;
    }

}
void MainWindow::eat_by_ghost()
{
    for(int a=0;a<4;a++)
    {
        if(pacman[0] == ghost[a][0] && pacman[1] == ghost[a][1])
        {
            //pacman_died=1;
            //win=2;
            life--;
            pacman[0] = (280+620)/2;
            pacman[1] = 350;

            if(life<0) {
                win=2;
                pacman_died=1;
            }
        }
    }
}

void MainWindow::Start_Game_Slots()
{
    map();
    score=0;
    life=3;
    re[0] = 0;
    win=0;
    god=0;
    god_time=0;
    pacman_died=0;
    point_how_many=0;
    block_timer = 0;
    for(int i=0;i<4;i++)
    {
      ghost_died[i]=0;
      ghost_relife[i]=0;
    }

    //ghost1_times = 0;
    pacman[0] = 0;
    pacman[1] = 0;
    pacman[2] = 0;
    pacman[3] = 0;

    ghost[0][0] = 210;
    ghost[0][1] = 210;
    ghost[0][2] = 0;
    ghost[0][3] = 0;

    ghost[1][0] = 280;
    ghost[1][1] = 210;
    ghost[1][2] = 0;
    ghost[1][3] = 0;

    ghost[2][0] = 350;
    ghost[2][1] = 210;
    ghost[2][2] = 0;
    ghost[2][3] = 0;

    ghost[3][0] = 420;
    ghost[3][1] = 210;
    ghost[3][2] = 0;
    ghost[3][3] = 0;
}

void MainWindow::is_win()
{
    if(point_how_many==119) win=1;
    if(win==1)
    {
        QMessageBox::information(this,"score","Win！",QMessageBox::Yes);
        Start_Game_Slots();
    }
    else if(win==2)
    {
        QMessageBox::information(this,"score","Lose！",QMessageBox::Yes);
        Start_Game_Slots();
    }
}

void MainWindow::ghost_go(int a,int x)
{
    if(x == 5 || x == 6)
    {
        turn_mode(x,a+1);
    }
    else
    {
        ghost[a][2] = 0;
        ghost[a][3] = 0;
        turn_mode(x,a+1);
    }
}

void MainWindow::showTime()
{
    for(int i=0;i<5;i++)
        for(int j=0;j<4;j++)
            canturn[i][j] = 0;
    block_timer++;
    pacman[0] += 10*pacman[2];
    pacman[1] += 10*pacman[3];

    move_baby *B;
    move_pacman P;
    move_ghost1 G1;

    B = &P;
    B = &G1;

    int x = B-> move(pacman[0],pacman[1]);
    if(x == 5 || x == 6)
    {
        turn_mode(x,0);
    }
    else
    {
        pacman[2] = 0;
        pacman[3] = 0;
        turn_mode(x,0);
    }
    int number = 0;
    if(point_how_many>10 && ghost[0][0] %5 ==0 && ghost[0][1] %5 == 0) number = 1;


    switch(number)
    {
     case 0:
        ghost[0][0] += 1*ghost[0][2];
        ghost[0][1] += 1*ghost[0][3];
        break;
     default:
        ghost[0][0] += 5*ghost[0][2];
        ghost[0][1] += 5*ghost[0][3];
        break;
    }
    ghost_go(0,B-> move(ghost[0][0],ghost[0][1]));
    if(ghost[0][2]==0 && ghost[0][3]==0 ) control_ghost1();

    ghost[1][0] += 5*ghost[1][2];
    ghost[1][1] += 5*ghost[1][3];
    ghost_go(1,B-> move(ghost[1][0],ghost[1][1]));
    if(ghost[1][2]==0 && ghost[1][3]==0 ) control_ghost2();

    ghost[2][0] += 5*  ghost[2][2];
    ghost[2][1] += 5*  ghost[2][3];
    ghost_go(2,B-> move(  ghost[2][0],  ghost[2][1]));
    if(  ghost[2][2]==0 &&   ghost[2][3]==0 ) control_ghost3();

    ghost[3][0] += 5*  ghost[3][2];
    ghost[3][1] += 5*  ghost[3][3];
    ghost_go(3,B-> move(  ghost[3][0],  ghost[3][1]));
    if(  ghost[3][2]==0 &&   ghost[3][3]==0 ) control_ghost4();

    eat_point();
    if(god==0) eat_by_ghost();
    else if(god==1) eat_ghost();
    for(int t=0;t<4;t++)
    {
        if(ghost_died[t] == 1)
        {
            ghost_relife[t]++;
            if(ghost_relife[t]==100)
            {
                ghost_died[t] = 0;
                ghost_relife[t]=0;
            }
        }
    }

    if(god==1)
    {
        god_time++;
        if(god_time == 200)
        {
            god_time=0;
            god=0;
        }
    }
    is_win();

    myLCDNumber->display(score);
    this->repaint();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawImage(QRect(0,0,900,900),QImage(":/image/level1.PNG"));
    //point
    for(int i=0;i<13;i++){
        for(int j=0;j<13;j++){
           if(point_small[i][j] == 1) painter.drawImage(QRect(i*70,j*70,70,70),QImage(":/image/small_ball.PNG"));
           else if(point_small[i][j] == 2) painter.drawImage(QRect(i*70,j*70,40,40),QImage(":/image/big_ball.png"));
        }
    }
    //pacman
    if(god==0)
    {
        if(pacman_died==0)
        {
            if( pacman[2]==-1)
            {
              painter.drawImage(QRect(pacman[0],pacman[1],70,70),QImage(":/image/left.PNG"));
            }
            else if(pacman[2]==1)
            {
              painter.drawImage(QRect(pacman[0],pacman[1],70,70),QImage(":/image/right.PNG"));
            }
            else if(pacman[3]==1)
            {
              painter.drawImage(QRect(pacman[0],pacman[1],70,70),QImage(":/image/down.PNG"));
            }
            else if(pacman[3]==-1)
            {
              painter.drawImage(QRect(pacman[0],pacman[1],70,70),QImage(":/image/up.PNG"));
            }
            else
            {
              painter.drawImage(QRect(pacman[0],pacman[1],70,70),QImage(":/image/stop.PNG"));
            }
        }

        painter.drawImage(QRect(ghost[0][0],ghost[0][1],70,70),QImage(":/image/ghost1.PNG"));
        painter.drawImage(QRect(ghost[1][0],ghost[1][1],70,70),QImage(":/image/ghost2.PNG"));
        painter.drawImage(QRect(ghost[2][0],ghost[2][1],70,70),QImage(":/image/ghost3.PNG"));
        painter.drawImage(QRect(ghost[3][0],ghost[3][1],70,70),QImage(":/image/ghost4.PNG"));
    }
    else if(god==1)
    {
        painter.drawImage(QRect(pacman[0],pacman[1],70,70),QImage(":/image/god.PNG"));
        if(ghost_died[0]==0) painter.drawImage(QRect(ghost[0][0],ghost[0][1],70,70),QImage(":/image/slow_ghost.PNG"));
        if(ghost_died[1]==0) painter.drawImage(QRect(ghost[1][0],ghost[1][1],70,70),QImage(":/image/slow_ghost.PNG"));
        if(ghost_died[2]==0) painter.drawImage(QRect(ghost[2][0],ghost[2][1],70,70),QImage(":/image/slow_ghost.PNG"));
        if(ghost_died[3]==0) painter.drawImage(QRect(ghost[3][0],ghost[3][1],70,70),QImage(":/image/slow_ghost.PNG"));
    }

    if(block_timer < 300) {
        painter.drawImage(QRect(210,280,70,70),QImage(":/image/wall.png"));
        painter.drawImage(QRect(690,210,70,70),QImage(":/image/wall.png"));
        painter.drawImage(QRect(620,280,70,70),QImage(":/image/wall.png"));
    }

    if(life > 0) painter.drawImage(QRect(900,800,70,70),QImage(":/image/apple.png"));
    if(life > 1) painter.drawImage(QRect(970,800,70,70),QImage(":/image/apple.png"));
    if(life > 2) painter.drawImage(QRect(1040,800,70,70),QImage(":/image/apple.png"));

    //QPen pen(Qt::red, 5,Qt::SolidLine, Qt::RoundCap,Qt::RoundJoin);
    //painter.setPen(pen);
    //painter.drawRect(0,0,100,40);
}
