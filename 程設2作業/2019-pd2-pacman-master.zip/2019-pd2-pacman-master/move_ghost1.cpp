#include "move_ghost1.h"

move_ghost1::move_ghost1()
{

}

int move_ghost1::move(double a,double b)
{
    int turn = 0;
    //outer
    if( a == 840 &&  b>0 &&  b<840) turn =5 ;//a point in not identity
    if( a == 70 &&  b>70 &&  b<770) turn =5 ;//a point in not identity
    if( a == 770 &&  b>70 &&  b<770) turn =5 ;//a point in not identity
    if( a == 0 &&  b>0 &&  b<840) turn =5 ;//a point in not identity
    if( a == 210 &&  b>210 &&  b<630) turn =5 ;//a point in not identity
    if( a == 630 &&  b>210 &&  b<630) turn =5 ;//a point in not identity

    if( b <211)
    {
        if( b == 70)
        {
            if( a>70 &&  a<770) turn =6 ;
            else if( a == 70)
            {
                turn =9 ;
            }
            else if( a == 770)
            {
                turn =10 ;
            }
        }
        else if( b == 0)
        {
            if( a>0 &&  a<840) turn =6 ;
            else if( a == 0)
            {
                turn =9 ;
            }
            else if( a == 840)
            {
                turn =10 ;
            }
        }
        else if( b == 210)
        {
            if( a>210 &&  a<630) turn =6 ;
            else if( a>630 &&  a<770) turn =6 ;
            else if( a>770 &&  a<840) turn =6 ;
            else if( a == 210)
            {
                turn =9 ;
            }
            else if( a == 630)
            {
                turn =11 ;
            }
            else if( a == 770)
            {
                turn =15 ;
            }
            else if( a == 840)
            {
                turn =14 ;
            }
        }
    }
    else
    {
        if( b == 840)
        {
            if( a>0 &&  a<840) turn =6 ;
            else if( a == 0)
            {
                turn =7 ;
            }
            else if( a == 840)
            {
                turn =8 ;
            }
        }
        else if( b == 630)
        {
            if( a>0 &&  a<70) turn =6 ;
            else if( a>70 &&  a<210) turn =6 ;
            else if( a>210 &&  a<630) turn =6 ;
            else if( a == 0)
            {
                turn =13 ;
            }
            else if( a == 70)
            {
                turn =15 ;
            }
            else if( a == 210)
            {
                turn =12 ;
            }
            else if( a == 630)
            {
                turn =8 ;
            }
        }
        else if( b == 770)
        {
            if( a>70 &&  a<770) turn =6 ;
            else if( a == 70)
            {
                turn =7 ;
            }
            else if( a == 770)
            {
                turn =8 ;
            }
        }
        else if( b == 350)
        {
            if( a>210 &&  a<630) turn =6 ;
            else if( a == 210)
            {
                turn =13 ;
            }
            else if( a == 630)
            {
                turn =14 ;
            }
        }

    }

    return turn;
}
