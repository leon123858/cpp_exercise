#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QPaintEvent>
#include <QPainter>
#include <QPalette>
#include <QMouseEvent>
#include <QLabel>
#include <QTimer>
#include <QString>
#include <QPushButton>
#include <QMessageBox>
#include <QTimer>
#include <QTime>
#include <QLCDNumber>
#include <QVector>
#include <QKeyEvent>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    Ui::MainWindow *ui;
    int god;
    int pacman_died;
    int ghost_died[4];
    int ghost_relife[4];
    int re[5];
    int pacman[4];
    int ghost[4][4];
    int canturn[5][4];
    int point_small[13][13];
    int ghost1_times;
    int score;
    int win;
    int god_time;
    int point_how_many;//119 for all
    int block_timer;
    int life;
    QPushButton *Start_Game;
    QTimer *myTimer;
    void keyPressEvent(QKeyEvent *event);
    void is_win();
    void paintEvent(QPaintEvent *);
    //void ghost1_go();
    void ghost_go(int a,int x);
    void control_ghost1();
    void control_ghost2();
    void control_ghost3();
    void control_ghost4();
    //void pacman_go();
    void eat();
    void eat_point();
    void eat_ghost();
    void eat_by_ghost();
    void ghost_turn(int a ,int b);
    void turn_mode(int a,int b);
    void map(/*double a,double b,int c,int d*/);
    void map_ghost0();

    QLCDNumber *myLCDNumber;

public slots:
    void Start_Game_Slots();
    void showTime();


};

#endif // MAINWINDOW_H
