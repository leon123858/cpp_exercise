#ifndef MOVE_PACMAN_H
#define MOVE_PACMAN_H
#include"move_baby.h"

class move_pacman : public move_baby
{
public:
    move_pacman();
    int move(double a,double b);
};

#endif // MOVE_PACMAN_H
