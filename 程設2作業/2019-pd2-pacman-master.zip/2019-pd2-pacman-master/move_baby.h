#ifndef MOVE_BABY_H
#define MOVE_BABY_H


class move_baby
{
public:
    move_baby();
    virtual int move(double a,double b) = 0;
};

#endif // MOVE_BABY_H
