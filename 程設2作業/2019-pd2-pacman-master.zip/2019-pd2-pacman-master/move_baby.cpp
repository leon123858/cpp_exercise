#include "move_baby.h"

move_baby::move_baby()
{

}


