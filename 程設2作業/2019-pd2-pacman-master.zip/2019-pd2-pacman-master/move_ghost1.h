#ifndef MOVE_GHOST1_H
#define MOVE_GHOST1_H
#include"move_baby.h"

class move_ghost1 : public move_baby
{
public:
    move_ghost1();
    int move(double a,double b);
};

#endif // MOVE_GHOST1_H
