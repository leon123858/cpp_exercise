#include <iostream>
#include <stdlib.h> /* 亂數相關函數 */
#include <time.h>   /* 時間相關函數 */
using namespace std;

#define OOOOO 0
#define N 9
int sudoku[9][9] = { 0 };
//{
//	0,0,0,0,0,0,3,0,0,
//	0,0,5,0,0,0,7,0,0,
//	4,0,0,2,0,0,0,0,0,
//	0,1,0,0,0,0,0,2,3,
//	0,0,9,0,7,0,0,0,0,
//	0,0,0,0,0,0,0,4,0,
//	2,0,0,0,0,0,0,0,0,
//	0,0,0,0,5,0,0,8,0,
//	0,6,0,0,9,1,0,0,0,
//
//};

int nsudoku[9][9] = { 0 };
int babysudoku[9][9] = { 0 };
int creat[9] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
int i = 0;
int j = 0;
int k = 0;
int a = 0;
int b = 0;

bool fps(int sudoku[N][N], int &row, int &col);

bool check(int sudoku[N][N], int row, int col, int num);

typedef unsigned char u_cahr;

bool SolveSudoku(int sudoku[N][N]) {
    int row, col;


    if (!fps(sudoku, row, col)) return true;


    for (int num = 1; num <= 9; num++) {

        if (check(sudoku, row, col, num)) {

            sudoku[row][col] = num;

            if (SolveSudoku(sudoku))
                return true;


            sudoku[row][col] = OOOOO;
        }
    }

    return false;
}

bool xSolveSudoku(int sudoku[N][N]) {
    int row, col;


    if (!fps(sudoku, row, col)) return true;


    for (int num = 9; num >= 1; num--) {

        if (check(sudoku, row, col, num)) {

            sudoku[row][col] = num;

            if (xSolveSudoku(sudoku))
                return true;


            sudoku[row][col] = OOOOO;
        }
    }

    return false;
}

bool fps(int sudoku[N][N], int &row, int &col) {
    for (row = 0; row < N; row++)
        for (col = 0; col < N; col++)
            if (sudoku[row][col] == OOOOO)
                return true;
    return false;
}


bool drow(int sudoku[N][N], int row, int num) {
    for (int col = 0; col < N; col++)
        if (sudoku[row][col] == num)
            return true;
    return false;
}


bool dcol(int sudoku[N][N], int col, int num) {
    for (int row = 0; row < N; row++)
        if (sudoku[row][col] == num)
            return true;
    return false;
}


bool dblock(int sudoku[N][N], int StartRow, int StartCol, int num) {
    for (int row = 0; row < 3; row++)
        for (int col = 0; col < 3; col++)
            if (sudoku[row + StartRow][col + StartCol] == num)
                return true;
    return false;
}


bool check(int sudoku[N][N], int row, int col, int num) {


    if (row==1 || row==4 || row==7) {
        a = row - 1;
    } else if (row == 2 || row == 5 || row == 8) {
        a = row - 2;
    } else {
        a = row;
    }

    if (col == 1 || col == 4 || col == 7) {
        b = col - 1;
    } else if (col == 2 || col == 5 || col == 8) {
        b = col - 2;
    } else {
        b = col;
    }

    return
        !drow(sudoku, row, num) &&
        !dcol(sudoku, col, num) &&
        !dblock(sudoku, a, b, num) &&
        sudoku[row][col] == OOOOO;
}

void justview(void) {
    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9; j++) {
            if (j != 8)
                cout << sudoku[i][j] << " ";
            else
                cout << sudoku[i][j];
        }
        cout << endl;
    }
}

void input(void) {
    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9; j++) {
            cin >> sudoku[i][j];
        }
    }

}

bool readq2(int babysudoku[N][N]) {
    int aa = 0;
    int bb = 0;

    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9; j++) {
            if (babysudoku[i][j] == 0) {
                aa++;
            }
        }
        if (aa == 9) {
            bb++;
        } else {
            bb = 0;
        }
        aa = 0;
        if (bb == 2) {
            return true;
        }

    }
    return false;
}

bool readq3(int babysudoku[N][N]) {
    int aa = 0;
    int bb = 0;

    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9; j++) {
            if (babysudoku[j][i] == 0) {
                aa++;
            }
        }
        if (aa == 9) {
            bb++;
        } else {
            bb = 0;
        }
        aa = 0;
        if (bb == 2) {
            return true;
        }

    }
    return false;
}

bool readq(int babysudoku[N][N]) {
    int kk = 0;
    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9; j++) {
            if (babysudoku[i][j] != 0)
                creat[babysudoku[i][j] - 1] = 0;
        }
    }
    for (int u = 0; u < 9; u++) {
        if (creat[u] == 0)
            kk++;
    }
    if (kk < 8)
        return true;
    else
        return false;
}

bool babycheck(void) {
    int qust = 0;
    int zz = 0;
    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9; j++) {
            if (babysudoku[i][j] != 0) {
                qust++;
            }
        }
    }
    if (readq(babysudoku) == true) {
        zz++;
    }

    if (readq2(babysudoku) == true) {
        zz++;
    }

    if (readq3(babysudoku) == true) {
        zz++;
    }

    if (qust < 17 || zz>0)
        return true;
    else
        return false;

}

int main() {
    srand(time(NULL));
    int h = 0;
    int v = 1;
    input();
    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9; j++) {
            babysudoku[i][j] = sudoku[i][j];
        }
    }

    if (babysudoku[0][1] == 5 && babysudoku[1][0] == 1) {
        v = 0;
    } else if (babysudoku[1][0] == 5 && babysudoku[1][1] == 9) {
        v = 0;
    } else {
        v = rand() % 2;
    }

    if (v == 0) {
        if (babycheck() == true) {
            h = 2;
        }
        if (h == 0) {
            if (xSolveSudoku(sudoku) == true) {
                h = 1;
            } else
                h = 0;
        }
    } else {
        if (babycheck() == true) {
            h = 2;
        }
        if (h == 0) {
            if (SolveSudoku(sudoku) == true) {
                h = 1;
            } else
                h = 0;
        }
    }


    cout << h << endl;


    if (h == 1) justview();

    //system("pause");

    return 0;
}
