#ifndef SUDOKU_H
#define SUDOKU_H

#include <iostream>
#include <vector>
#include <math.h>
#include <stdlib.h> /* 亂數相關函數 */
#include <time.h>   /* 時間相關函數 */
#include <algorithm>
#include <ctime>

using namespace std;

#define OOOOO 0
#define N 9
int sudoku[9][9] = { 0 };



int nsudoku[9][9] = { 0 };
int babysudoku[9][9] = { 0 };
int finding[9] = { 0 };
int creat[9] = { 0 };
int newspace[9] = { 0 };
int space[9] = { 0 };
vector <int>  row, col, sudspace;
vector<vector<int> > maybe(81, vector<int>(0, 0));
int i = 0;
int j = 0;
int k = 0;
int x = 0;
int p = 0;
int b = 0;
int h = 0;
int y = 0;
int t = 0;
int g = 0;





bool fps(int sudoku[N][N], int &row, int &col);

bool check(int sudoku[N][N], int row, int col, int num);

typedef unsigned char u_cahr;

bool SolveSudoku(int sudoku[N][N]) {
    int row, col;


    if (! fps(sudoku, row, col))
        return true;

    for (int num = 1; num <= 9; num++) {

        if (check(sudoku, row, col, num)) {

            sudoku[row][col] = num;


            if (SolveSudoku(sudoku))
                return true;


            sudoku[row][col] = OOOOO;
        }
    }
    return false;
}


bool fps(int sudoku[N][N], int &row, int &col) {
    for (row = 0; row < N; row++)
        for (col = 0; col < N; col++)
            if (sudoku[row][col] == OOOOO)
                return true;
    return false;
}


bool drow(int sudoku[N][N], int row, int num) {
    for (int col = 0; col < N; col++)
        if (sudoku[row][col] == num)
            return true;
    return false;
}


bool dcol(int sudoku[N][N], int col, int num) {
    for (int row = 0; row < N; row++)
        if (sudoku[row][col] == num)
            return true;
    return false;
}


bool dblock(int sudoku[N][N], int StartRow, int StartCol, int num) {
    for (int row = 0; row < 3; row++)
        for (int col = 0; col < 3; col++)
            if (sudoku[row + StartRow][col + StartCol] == num)
                return true;
    return false;
}


bool check(int sudoku[N][N], int row, int col, int num) {

    return
        !drow(sudoku, row, num) &&
        !dcol(sudoku, col, num) &&
        !dblock(sudoku, row - row % 3, col - col % 3, num) &&
        sudoku[row][col] == OOOOO;
}



//by init
void cr(void) {
    creat[9] = { 0 };
    for (i = 1; i <=9 ; i++) {
        creat[i - 1] = i;
    }


    for (x = 0; x <=8; x++) {
        j = rand() % 9 ;
        k = creat[x];
        p = creat[j];
        creat[x] = p;
        creat[j] = k;
    }
}
void remembernsudoku(void) {
    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9; j++) {
            nsudoku[i][j] = sudoku[i][j];
        }
    }
}
void changeblock(int a, int b) {
    if (a + b == 1) {
        for (i = 0; i < 3; i++) {
            for (j = 0; j < 9; j++) {
                sudoku[i][j] = nsudoku[3 + i][j];
            }
        }
        for (i = 3; i < 6; i++) {
            for (j = 0; j < 9; j++) {
                sudoku[i][j] = nsudoku[i - 3][j];
            }
        }
    } else if (a + b == 2) {
        for (i = 0; i < 3; i++) {
            for (j = 0; j < 9; j++) {
                sudoku[i][j] = nsudoku[6 + i][j];
            }
        }
        for (i = 6; i < 9; i++) {
            for (j = 0; j < 9; j++) {
                sudoku[i][j] = nsudoku[i - 6][j];
            }
        }
    } else if (a + b == 3) {
        for (i = 3; i < 6; i++) {
            for (j = 0; j < 9; j++) {
                sudoku[i][j] = nsudoku[3 + i][j];
            }
        }
        for (i = 6; i < 9; i++) {
            for (j = 0; j < 9; j++) {
                sudoku[i][j] = nsudoku[i - 3][j];
            }
        }
    } else if (a == b) {
        cout << "wrong" << endl;
    } else {
        cout << "wrong" << endl;
    }

}
void changeblock2(int a, int b) {
    if (a + b == 1) {
        for (i = 0; i < 9; i++) {
            for (j = 0; j < 3; j++) {
                sudoku[i][j] = nsudoku[i][j+3];
            }
        }
        for (i = 0; i < 9; i++) {
            for (j = 3; j < 6; j++) {
                sudoku[i][j] = nsudoku[i][j-3];
            }
        }
    } else if (a + b == 2) {
        for (i = 0; i < 9; i++) {
            for (j = 0; j < 3; j++) {
                sudoku[i][j] = nsudoku[i][6+j];
            }
        }
        for (i = 0; i < 9; i++) {
            for (j = 6; j < 9; j++) {
                sudoku[i][j] = nsudoku[i][j-6];
            }
        }
    } else if (a + b == 3) {
        for (i = 0; i < 9; i++) {
            for (j = 3; j < 6; j++) {
                sudoku[i][j] = nsudoku[i][j+3];
            }
        }
        for (i = 0; i < 9; i++) {
            for (j = 6; j < 9; j++) {
                sudoku[i][j] = nsudoku[i][j-3];
            }
        }
    } else if (a == b) {
        cout << "wrong" << endl;
    } else {
        cout << "wrong" << endl;
    }

}
void changenumber(int x, int y) {
    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9; j++) {
            if (sudoku[i][j] == x) {
                sudoku[i][j] = y;
            } else if (sudoku[i][j] == y) {
                sudoku[i][j] = x;
            }
        }
    }
}
void rotate() {
    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9; j++) {
            sudoku[i][j] = nsudoku[abs(8 - j)][i];
        }
    }
}
void glass(int a) {
    if (a == 0) {
        for (i = 0; i < 9; i++) {
            for (j = 0; j < 9; j++) {
                sudoku[i][j] = nsudoku[abs(8 - i)][j];
            }
        }
    } else {
        for (i = 0; i < 9; i++) {
            for (j = 0; j < 9; j++) {
                sudoku[i][j] = nsudoku[(i)][abs(8 - j)];
            }
        }
    }
}
void justview(void) {
    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9; j++) {
            if (j != 8)
                cout << sudoku[i][j] << " ";
            else
                cout << sudoku[i][j];
        }
        cout << endl;
    }
}
void view(void) {
    h = 0;
    x = 0;
    y = 0;
    cin >> h;
    if (h == 1, 2, 3)
        cin >> x >> y;
    if (h == 4, 5)
        cin >> x;
    switch (h) {
    case 1://換數字
        changenumber(x, y);
        justview();
        break;
    case 2://三大行對調
        remembernsudoku();
        changeblock(x, y);
        justview();
        break;
    case 3:
        remembernsudoku();
        changeblock2(x, y);
        justview();
        break;
    case 4:
        for (k = 0; k < x; k++) {
            remembernsudoku();
            rotate();
        }
        justview();
        break;
    case 5:
        remembernsudoku();
        glass(x);
        justview();
        break;
    default:
        b = 0;//stop point
        justview();
    }

}

void inin(int a, int b,int c,int d) {
    k = 0;
    for (i = a; i < b; i++) {
        for (j = c; j < d; j++) {
            sudoku[i][j] = creat[k];
            k++;
        }
    }

}

void changeclun(int a) { //直行對調
    for (j = 0; j < 7; j=j+3) {
        if (a == 0) {
            creat[j] = finding[j + 2];
            creat[j + 1] = finding[j];
            creat[j + 2] = finding[j + 1];
        }
        if (a == 1) {
            creat[j] = finding[j + 1];
            creat[j + 1] = finding[j+2];
            creat[j + 2] = finding[j];
        }
    }
}

void nchangeclun(int a) { //直行對調
    for (j = 0; j < 7; j = j + 3) {
        if (a == 0) {
            creat[j] = newspace[j + 2];
            creat[j + 1] = newspace[j];
            creat[j + 2] = newspace[j + 1];
        }
        if (a == 1) {
            creat[j] = newspace[j + 1];
            creat[j + 1] = newspace[j + 2];
            creat[j + 2] = newspace[j];
        }
    }
}

void changrow(int a) { //恆對調
    if (a == 0) {
        creat[0] = finding[6];
        creat[1] = finding[7];
        creat[2] = finding[8];

        creat[3] = finding[0];
        creat[4] = finding[1];
        creat[5] = finding[2];

        creat[6] = finding[3];
        creat[7] = finding[4];
        creat[8] = finding[5];
    }
    if (a == 1) {
        creat[0] = finding[3];
        creat[1] = finding[4];
        creat[2] = finding[5];

        creat[3] = finding[6];
        creat[4] = finding[7];
        creat[5] = finding[8];

        creat[6] = finding[0];
        creat[7] = finding[1];
        creat[8] = finding[2];
    }
}

void makefirst(void) {
    cr();
    inin(3, 6, 3, 6);
    for (i = 0; i < 9; i++) {
        finding[i] = creat[i];
    }
    changeclun(0);
    inin(0, 3, 3, 6);
    changeclun(1);
    inin(6, 9, 3, 6);
    changrow(0);
    inin(3, 6, 0, 3);
    changrow(1);
    inin(3, 6, 6, 9);

    changrow(0);
    for (i = 0; i < 9; i++) {
        newspace[i] = creat[i];
    }
    nchangeclun(0);
    inin(0, 3, 0, 3);
    nchangeclun(1);
    inin(6, 9, 0, 3);

    changrow(1);
    for (i = 0; i < 9; i++) {
        newspace[i] = creat[i];
    }
    nchangeclun(0);
    inin(0, 3, 6, 9);
    nchangeclun(1);
    inin(6, 9, 6, 9);
}

void makehole(void) {
    for (i = 0; i < 9; i++) {
        for (j = 0; j < 9; j++) {
            x = rand() % 4;
            if (x == 1) {
                sudoku[i][j] = 0;
            }
        }
    }
}

void input(void) {
    for (i = 0; i < 9; i++) {
        scanf("%d%d%d%d%d%d%d%d%d%d%", &space[0], &space[1], &space[2], &space[3], &space[4], &space[5], &space[6], &space[7], &space[8]);
        for (j = 0; j < 9; j++)
            sudoku[i][j] = space[j];
    }
}




#endif // SUDOKU_H
