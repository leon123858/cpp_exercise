#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QPaintEvent>
#include <QPainter>
#include <QPalette>
#include <QMouseEvent>
#include <QLabel>
#include <QTimer>
#include <QString>
#include <QPushButton>
#include <QMessageBox>
#include <QTimer>
#include <QTime>
#include <QLCDNumber>
#include <QVector>


class MainWindow : public QMainWindow
{
    Q_OBJECT
private:
    int Chessman_Coordinate[9][10];//view photo
    int To_Move[9][10];//caculate which can move
    int Regret[9][10][3];
    int died1;
    int died2;
    int Regret_number;
    int Clicked_X;
    int Clicked_Y;
    int step;
    int timing;
    std::vector<int> baby;
    //int Regret_times;

    bool Game_Is_Over;

    QPushButton *Start_Game;
    QPushButton *Special_Game;
    QPushButton *Regret_Game;

    QTimer *myTimer;
    QLCDNumber *myLCDNumber;

    QTimer *timer2;
    QLCDNumber *myLCDNumber2;

    QTimer *timer3;
    QLCDNumber *myLCDNumber3;
    QTimer *timer4;
    QLCDNumber *myLCDNumber4;


public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void Initialize_Array();
    void Special_Array();
    void Initialize_Move_Array();
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *event);
    void To_Move_Chessman(int i, int j, int value);
    void Eat_Chessman(int Eat_x, int Eat_y, int Eat_value, int Eaten_x, int Eaten_y, int Eaten_value);

    void Is_Win();
public slots:

    void Start_Game_Slots();
    void Special_Game_Slots();
    void Regret_Game_Slots();
    void showTime();
    void dothing();
    void catch_died1();
    void catch_died2();
};

#endif // MAINWINDOW_H
