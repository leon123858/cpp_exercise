#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
{
    this->setFixedSize(1100,1000);
    this->setWindowTitle("象棋");

    Start_Game=new QPushButton("start game",this);
    Start_Game->setGeometry(930,300,100,40);
    Start_Game->setFlat(1);

    Special_Game=new QPushButton("special game",this);
    Special_Game->setGeometry(930,400,100,40);
    Special_Game->setFlat(1);

    Regret_Game=new QPushButton("regret game",this);
    Regret_Game->setGeometry(930,500,100,40);
    Regret_Game->setFlat(1);

    connect(Start_Game,SIGNAL(clicked(bool)),this,SLOT(Start_Game_Slots()));
    connect(Special_Game,SIGNAL(clicked(bool)),this,SLOT(Special_Game_Slots()));
    connect(Regret_Game,SIGNAL(clicked(bool)),this,SLOT(Regret_Game_Slots()));

    myTimer = new QTimer(this);
    myLCDNumber = new QLCDNumber(this);
    myLCDNumber->setGeometry(930,100,100,40);
    myLCDNumber->setDigitCount(8);
    myTimer->start(1000);
    showTime();

    connect(myTimer,SIGNAL(timeout()),this,SLOT(showTime()));

    timer2 = new QTimer(this);
    myLCDNumber2 = new QLCDNumber(this);
    myLCDNumber2->setGeometry(930,700,100,40);
    myLCDNumber2->setDigitCount(3);
    timer2->start(1000);
    dothing();
    connect(timer2,SIGNAL(timeout()),this,SLOT(dothing()));

    timer3 = new QTimer(this);
    myLCDNumber3 = new QLCDNumber(this);
    myLCDNumber3->setGeometry(930,800,100,40);
    myLCDNumber3->setDigitCount(2);
    timer3->start(1000);
    catch_died1();
    connect(timer3,SIGNAL(timeout()),this,SLOT(catch_died1()));

    timer4 = new QTimer(this);
    myLCDNumber4 = new QLCDNumber(this);
    myLCDNumber4->setGeometry(930,0,100,40);
    myLCDNumber4->setDigitCount(2);
    timer4->start(1000);
    catch_died2();
    connect(timer4,SIGNAL(timeout()),this,SLOT(catch_died2()));

}

MainWindow::~MainWindow()
{
    delete this;
}
void MainWindow::catch_died1()
{
    myLCDNumber3->display(died1);
    std:baby.push_back(died1);
}
void MainWindow::catch_died2()
{
    myLCDNumber4->display(died2);
    std:baby.push_back(died2);
}
void MainWindow::dothing()
{
    timing++;
    //QString text=timing.toString("sss");
    if(timing>10)
    {
        if(step==0) step++;
        else step=0;
    }
    myLCDNumber2->display(timing);
}
void MainWindow::showTime()
{
    QTime time = QTime::currentTime();
    QString text=time.toString("hh,mm,ss");

    myLCDNumber->display(text);
}
void MainWindow::Special_Array()
{
    memset(Chessman_Coordinate,0,90*sizeof(int));//origin

    Chessman_Coordinate[5][0]=1;//black king
    //Chessman_Coordinate[3][0]=2;//士
    //Chessman_Coordinate[5][0]=2;
    Chessman_Coordinate[4][2]=3;//相
    //Chessman_Coordinate[6][0]=3;
    //Chessman_Coordinate[1][0]=4;//horse
    //Chessman_Coordinate[7][0]=4;
    Chessman_Coordinate[4][0]=5;//車
    //Chessman_Coordinate[8][0]=5;
    //Chessman_Coordinate[1][2]=6;//炮
    //Chessman_Coordinate[7][2]=6;

    Chessman_Coordinate[1][7]=7;
    Chessman_Coordinate[4][7]=7;
    Chessman_Coordinate[3][8]=7;
    Chessman_Coordinate[5][8]=7;

    Chessman_Coordinate[4][9]=-1;//red king
    //Chessman_Coordinate[3][9]=-2;
    //Chessman_Coordinate[5][9]=-2;
    //Chessman_Coordinate[2][9]=-3;
    //Chessman_Coordinate[6][9]=-3;
    //Chessman_Coordinate[1][9]=-4;
    //Chessman_Coordinate[7][9]=-4;
    Chessman_Coordinate[6][9]=-5;
    Chessman_Coordinate[7][9]=-5;
    //Chessman_Coordinate[1][7]=-6;
    Chessman_Coordinate[7][7]=-6;

    Chessman_Coordinate[3][1]=-7;
    Chessman_Coordinate[5][2]=-7;
    Chessman_Coordinate[8][5]=-7;

    Initialize_Move_Array();
}
void MainWindow::Initialize_Array()
{
    memset(Chessman_Coordinate,0,90*sizeof(int));//origin

    Chessman_Coordinate[4][0]=1;//black king
    Chessman_Coordinate[3][0]=2;//士
    Chessman_Coordinate[5][0]=2;
    Chessman_Coordinate[2][0]=3;//相
    Chessman_Coordinate[6][0]=3;
    Chessman_Coordinate[1][0]=4;//horse
    Chessman_Coordinate[7][0]=4;
    Chessman_Coordinate[0][0]=5;//車
    Chessman_Coordinate[8][0]=5;
    Chessman_Coordinate[1][2]=6;//炮
    Chessman_Coordinate[7][2]=6;
    for(int i=0;i<5;i++)//兵
    {
        Chessman_Coordinate[2*i][3]=7;
    }
    Chessman_Coordinate[4][9]=-1;//red king
    Chessman_Coordinate[3][9]=-2;
    Chessman_Coordinate[5][9]=-2;
    Chessman_Coordinate[2][9]=-3;
    Chessman_Coordinate[6][9]=-3;
    Chessman_Coordinate[1][9]=-4;
    Chessman_Coordinate[7][9]=-4;
    Chessman_Coordinate[0][9]=-5;
    Chessman_Coordinate[8][9]=-5;
    Chessman_Coordinate[1][7]=-6;
    Chessman_Coordinate[7][7]=-6;
    for(int i=0;i<5;i++)
    {
        Chessman_Coordinate[2*i][6]=-7;
    }
    Initialize_Move_Array();
}

void MainWindow::Initialize_Move_Array()
{
    for(int i=0;i<9;i++)
    {
        for(int j=0;j<10;j++)
        {
            To_Move[i][j]=Chessman_Coordinate[i][j];
        }
    }
}
void MainWindow::mousePressEvent(QMouseEvent *event)
{

    if(10<event->pos().x()&&event->pos().x()<=890&&
            10<event->pos().y()&&event->pos().y()<=990&& Game_Is_Over != true)
    {
        for(int i=0;i<9;i++)//change click place to coordinate
        {
            for(int j=0;j<10;j++)
            {
                if(10+100*i<=event->pos().x()&&event->pos().x()<10+100*(i+1)&&
                        10+100*j<=event->pos().y()&&event->pos().y()<10+100*(j+1))
                {

                    if(Chessman_Coordinate[i][j] > 0 && step==0)
                    {
                        Initialize_Move_Array();
                        To_Move_Chessman(i,j,Chessman_Coordinate[i][j]);

                    }
                    else if(Chessman_Coordinate[i][j] < 0 && step==1)
                    {
                        Initialize_Move_Array();
                        To_Move_Chessman(i,j,Chessman_Coordinate[i][j]);
                        Regret_number=0;
                    }
                    else if(To_Move[i][j]==10)
                    {
                        Eat_Chessman(Clicked_X,Clicked_Y,Chessman_Coordinate[Clicked_X][Clicked_Y],i,j,Chessman_Coordinate[i][j]);
                    }
                    else {
                        Initialize_Move_Array();
                        return;
                    }
                    Clicked_X = i;
                    Clicked_Y = j;
                    this->repaint();
                }
            }
        }
    }
}

void MainWindow::To_Move_Chessman(int i,int j,int value)
{//the move rule
    bool Is_Skip=false;
    int king_face[4];
    int king_Num;
    switch (value) {
    case 1://king rule
        if(i>3 && i<6 && Chessman_Coordinate[i-1][j]<=0) To_Move[i-1][j]=10;
        if(i<5 && i>2 && Chessman_Coordinate[i+1][j]<=0) To_Move[i+1][j]=10;
        if(j>0 && j<3 && Chessman_Coordinate[i][j-1]<=0) To_Move[i][j-1]=10;
        if(j>-1&& j<2 && Chessman_Coordinate[i][j+1]<=0) To_Move[i][j+1]=10;

        king_face[0] = i;
        king_face[1] = j;

        for(int x=0;x<9;x++)
        {
            for(int y=0;y<10;y++)
            {
              if(Chessman_Coordinate[x][y]==-1)
              {
                  king_face[2] = x;
                  king_face[3] = y;
              }
            }
        }
        king_Num=0;
        if(king_face[2] == king_face[0])
        {
            for(int y=0;y<10;y++)
            {
                if(Chessman_Coordinate[i][y] != 0) king_Num++;
            }
            if(king_Num == 2) To_Move[king_face[2]][king_face[3]]=10;
        }
        break;
    case 2://士
        /*if(i>3 && i<6 && Chessman_Coordinate[i-1][j+1]<=0 && j!=2) To_Move[i-1][j+1]=10;
        if(i>3 && i<6 && Chessman_Coordinate[i-1][j-1]<=0 && j!=0) To_Move[i-1][j-1]=10;
        if(i>5 && i<2 && Chessman_Coordinate[i+1][j+1]<=0 && j!=2) To_Move[i+1][j+1]=10;
        if(i>5 && i<2 && Chessman_Coordinate[i+1][j-1]<=0 && j!=0) To_Move[i+1][j-1]=10;
        if(j>0 && j<3 && Chessman_Coordinate[i-1][j+1]<=0 && i!=3) To_Move[i-1][j+1]=10;
        if(j>0 && j<3 && Chessman_Coordinate[i-1][j-1]<=0 && i!=3) To_Move[i-1][j-1]=10;
        if(j>-1 && j<2 && Chessman_Coordinate[i+1][j+1]<=0 && i!=5) To_Move[i+1][j+1]=10;
        if(j>-1 && j<2 && Chessman_Coordinate[i+1][j-1]<=0 && i!=5) To_Move[i+1][j-1]=10;*/
        if(Chessman_Coordinate[i-1][j+1]<=0 ) To_Move[i-1][j+1] = 10;
        if(Chessman_Coordinate[i-1][j-1]<=0 ) To_Move[i-1][j-1] = 10;
        if(Chessman_Coordinate[i+1][j+1]<=0 ) To_Move[i+1][j+1] = 10;
        if(Chessman_Coordinate[i+1][j-1]<=0 ) To_Move[i+1][j-1] = 10;

        if(i > 4)
        {
            To_Move[i+1][j+1] = 0;
            To_Move[i+1][j-1] = 0;
        }
        if(i < 4)
        {
            To_Move[i-1][j+1] = 0;
            To_Move[i-1][j-1] = 0;
        }
        if(j > 1)
        {
            To_Move[i+1][j+1] = 0;
            To_Move[i-1][j+1] = 0;
        }
        if(j < 1)
        {
            To_Move[i+1][j-1] = 0;
            To_Move[i-1][j-1] = 0;
        }
        break;
    case 3://相
        if(Chessman_Coordinate[i-2][j+2]<=0 ) To_Move[i-2][j+2] = 10;
        if(Chessman_Coordinate[i-2][j-2]<=0 ) To_Move[i-2][j-2] = 10;
        if(Chessman_Coordinate[i+2][j+2]<=0 ) To_Move[i+2][j+2] = 10;
        if(Chessman_Coordinate[i+2][j-2]<=0 ) To_Move[i+2][j-2] = 10;

        if(i > 6)
        {
            To_Move[i+2][j+2] = 0;
            To_Move[i+2][j-2] = 0;
        }
        if(i < 2)
        {
            To_Move[i-2][j+2] = 0;
            To_Move[i-2][j-2] = 0;
        }
        if(j > 2)
        {
            To_Move[i+2][j+2] = 0;
            To_Move[i-2][j+2] = 0;
        }
        if(j < 2)
        {
            To_Move[i+2][j-2] = 0;
            To_Move[i-2][j-2] = 0;
        }


        break;
    case 4://horse
        if(Chessman_Coordinate[i-1][j+2]<=0 && Chessman_Coordinate[i][j+1] == 0) To_Move[i-1][j+2] = 10;
        if(Chessman_Coordinate[i+1][j+2]<=0 && Chessman_Coordinate[i][j+1] == 0) To_Move[i+1][j+2] = 10;
        if(Chessman_Coordinate[i-1][j-2]<=0 && Chessman_Coordinate[i][j-1] == 0) To_Move[i-1][j-2] = 10;
        if(Chessman_Coordinate[i+1][j-2]<=0 && Chessman_Coordinate[i][j-1] == 0) To_Move[i+1][j-2] = 10;
        if(Chessman_Coordinate[i-2][j+1]<=0 && Chessman_Coordinate[i-1][j] == 0) To_Move[i-2][j+1] = 10;
        if(Chessman_Coordinate[i+2][j+1]<=0 && Chessman_Coordinate[i+1][j] == 0) To_Move[i+2][j+1] = 10;
        if(Chessman_Coordinate[i+2][j-1]<=0 && Chessman_Coordinate[i+1][j] == 0) To_Move[i+2][j-1] = 10;
        if(Chessman_Coordinate[i-2][j-1]<=0 && Chessman_Coordinate[i-1][j] == 0) To_Move[i-2][j-1] = 10;

        if( i-1<0 )
        {
            To_Move[i-1][j+2] = 0;
            To_Move[i-1][j-2] = 0;
        }
        if( i-2 < 0 )
        {
            To_Move[i-2][j+1] = 0;
            To_Move[i-2][j-1] = 0;
        }
        if( i+1 > 8 )
        {
            To_Move[i+1][j+2] = 0;
            To_Move[i+1][j-2] = 0;
        }
        if( i+2 > 8 )
        {
            To_Move[i+2][j+1] = 0;
            To_Move[i+2][j-1] = 0;
        }
        if( j-1<0 )
        {
            To_Move[i+2][j-1] = 0;
            To_Move[i-2][j-1] = 0;
        }
        if( j-2 < 0 )
        {
            To_Move[i+1][j-2] = 0;
            To_Move[i-1][j-2] = 0;
        }
        if( j+1 >9 )
        {
            To_Move[i+2][j+1] = 0;
            To_Move[i-2][j+1] = 0;
        }
        if( j+2 > 9 )
        {
            To_Move[i+1][j+2] = 0;
            To_Move[i-1][j+2] = 0;
        }

        break;
    case 5://car

        for(int x=1;x <= (8-i) ;x++)
        {
            To_Move[i+x][j]= 10;
            if(Chessman_Coordinate[i+x][j] > 0)
            {
                To_Move[i+x][j]= 0;
                break;
            }
            if(Chessman_Coordinate[i+x][j] < 0)
            {
                break;
            }
        }
        for(int x=1;x <= i ;x++)
        {
            To_Move[i-x][j]= 10;
            if(Chessman_Coordinate[i-x][j] > 0)
            {
                To_Move[i-x][j]= 0;
                break;
            }
            if(Chessman_Coordinate[i-x][j] < 0)
            {
                break;
            }
        }
        for(int x=1;x <= (9-j) ;x++)
        {
            To_Move[i][j+x]= 10;
            if(Chessman_Coordinate[i][j+x] > 0)
            {
                To_Move[i][j+x]= 0;
                break;
            }
            if(Chessman_Coordinate[i][j+x] < 0)
            {
                break;
            }
        }
        for(int x=1;x <= j ;x++)
        {
            To_Move[i][j-x]= 10;
            if(Chessman_Coordinate[i][j-x] > 0)
            {
                To_Move[i][j-x]= 0;
                break;
            }
            if(Chessman_Coordinate[i][j-x] < 0)
            {
                break;
            }
        }
        break;
    case 6://炮
        for(int x=1;x <= (8-i) ;x++)
        {
            To_Move[i+x][j]= 10;
            if(Chessman_Coordinate[i+x][j] > 0 || Chessman_Coordinate[i+x][j] < 0)
            {
                To_Move[i+x][j]= 0;
                for(int y=x+1; y<= (8-i);y++)
                {
                    if(Chessman_Coordinate[i+y][j] < 0)
                    {
                        To_Move[i+y][j]= 10;
                        break;
                    }
                }
                break;
            }
        }
        for(int x=1;x <= i ;x++)
        {
            To_Move[i-x][j]= 10;
            if(Chessman_Coordinate[i-x][j] > 0 || Chessman_Coordinate[i-x][j] < 0)
            {
                To_Move[i-x][j]= 0;
                for(int y=x+1; y<= i ;y++)
                {
                    if(Chessman_Coordinate[i-y][j] < 0)
                    {
                        To_Move[i-y][j]= 10;
                        break;
                    }
                }
                break;
            }
        }
        for(int x=1;x <= (9-j) ;x++)
        {
            To_Move[i][j+x]= 10;
            if(Chessman_Coordinate[i][j+x] > 0 || Chessman_Coordinate[i][j+x] < 0)
            {
                To_Move[i][j+x]= 0;
                for(int y=x+1; y<= (9-j);y++)
                {
                    if(Chessman_Coordinate[i][j+y] < 0)
                    {
                        To_Move[i][j+y]= 10;
                        break;
                    }
                }
                break;
            }
        }
        for(int x=1;x <= j ;x++)
        {
            To_Move[i][j-x]= 10;
            if(Chessman_Coordinate[i][j-x] > 0 || Chessman_Coordinate[i][j-x] < 0)
            {
                To_Move[i][j-x]= 0;
                for(int y=x+1; y<= j;y++)
                {
                    if(Chessman_Coordinate[i][j-y] < 0)
                    {
                        To_Move[i][j-y]= 10;
                        break;
                    }
                }
                break;
            }
        }
        break;
    case 7://兵
        if(j+1 != 10)
        {
            To_Move[i][j+1]=10;
            if(Chessman_Coordinate[i][j+1] > 0) To_Move[i][j+1]=10;
        }
        if(i+1 != 9 && j>=5) {
            To_Move[i+1][j]=10;
            if(Chessman_Coordinate[i][j+1] > 0) To_Move[i+1][j]=10;
        }
        if(i-1 != -1 && j>=5) {
            To_Move[i-1][j]=10;
            if(Chessman_Coordinate[i][j+1] > 0) To_Move[i-1][j]=10;
        }
        break;
    case -1:
        if(i-1>=3&&Chessman_Coordinate[i-1][j]>=0) To_Move[i-1][j]=10;
        if(i+1<=5&&Chessman_Coordinate[i+1][j]>=0) To_Move[i+1][j]=10;
        if(j-1>=7&&Chessman_Coordinate[i][j-1]>=0) To_Move[i][j-1]=10;
        if(j+1<=9&&Chessman_Coordinate[i][j+1]>=0) To_Move[i][j+1]=10;
        king_face[0] = i;
        king_face[1] = j;

        for(int x=0;x<9;x++)
        {
            for(int y=0;y<10;y++)
            {
              if(Chessman_Coordinate[x][y]==1)
              {
                  king_face[2] = x;
                  king_face[3] = y;
              }
            }
        }
        king_Num=0;
        if(king_face[2] == king_face[0])
        {
            for(int y=0;y<10;y++)
            {
                if(Chessman_Coordinate[i][y] != 0) king_Num++;
            }
            if(king_Num == 2) To_Move[king_face[2]][king_face[3]]=10;
        }
        break;
    case -2:
        if(i-1>=3&&j-1>=7&&Chessman_Coordinate[i-1][j-1]>=0) To_Move[i-1][j-1]=10;
        if(i-1>=3&&j+1<=9&&Chessman_Coordinate[i-1][j+1]>=0) To_Move[i-1][j+1]=10;
        if(i+1<=5&&j-1>=7&&Chessman_Coordinate[i+1][j-1]>=0) To_Move[i+1][j-1]=10;
        if(i+1<=5&&j+1<=9&&Chessman_Coordinate[i+1][j+1]>=0) To_Move[i+1][j+1]=10;
        break;
    case -3:
        if(i-2>=0&&j-2>=5&&Chessman_Coordinate[i-2][j-2]>=0) To_Move[i-2][j-2]=10;
        if(i-2>=0&&j+2<=9&&Chessman_Coordinate[i-2][j+2]>=0) To_Move[i-2][j+2]=10;
        if(i+2<=8&&j-2>=5&&Chessman_Coordinate[i+2][j-2]>=0) To_Move[i+2][j-2]=10;
        if(i+2<=8&&j+2<=9&&Chessman_Coordinate[i+2][j+2]>=0) To_Move[i+2][j+2]=10;
        break;
    case -4:
        if(i-2>=0&&j-1>=0&&Chessman_Coordinate[i-1][j]==0&&Chessman_Coordinate[i-2][j-1]>=0) To_Move[i-2][j-1]=10;
        if(i-1>=0&&j-2>=0&&Chessman_Coordinate[i][j-1]==0&&Chessman_Coordinate[i-1][j-2]>=0) To_Move[i-1][j-2]=10;
        if(i-2>=0&&j+1<=9&&Chessman_Coordinate[i-1][j]==0&&Chessman_Coordinate[i-2][j+1]>=0) To_Move[i-2][j+1]=10;
        if(i-1>=0&&j+2<=9&&Chessman_Coordinate[i][j+1]==0&&Chessman_Coordinate[i-1][j+2]>=0) To_Move[i-1][j+2]=10;
        if(i+2<=8&&j-1>=0&&Chessman_Coordinate[i+1][j]==0&&Chessman_Coordinate[i+2][j-1]>=0) To_Move[i+2][j-1]=10;
        if(i+1<=8&&j-2>=0&&Chessman_Coordinate[i][j-1]==0&&Chessman_Coordinate[i+1][j-2]>=0) To_Move[i+1][j-2]=10;
        if(i+2<=8&&j+1<=9&&Chessman_Coordinate[i+1][j]==0&&Chessman_Coordinate[i+2][j+1]>=0) To_Move[i+2][j+1]=10;
        if(i+1<=8&&j+2<=9&&Chessman_Coordinate[i][j+1]==0&&Chessman_Coordinate[i+1][j+2]>=0) To_Move[i+1][j+2]=10;
        break;
    case -5:
        for(int x=1;x<=8;x++)
        {
            if(i+x<=8&&Chessman_Coordinate[i+x][j]==0) To_Move[i+x][j]=10;
            else  if(i+x<=8&&Chessman_Coordinate[i+x][j]>0)
            {
                To_Move[i+x][j]=10;
                break;
            }
            else break;
        }
        for(int x=1;x<=8;x++)
        {
            if(i-x>=0&&Chessman_Coordinate[i-x][j]==0) To_Move[i-x][j]=10;
            else  if(i-x>=0&&Chessman_Coordinate[i-x][j]>0)
            {
                To_Move[i-x][j]=10;
                break;
            }
            else break;
        }
        for(int x=1;x<=9;x++)
        {
            if(j+x<=9&&Chessman_Coordinate[i][j+x]==0) To_Move[i][j+x]=10;
            else  if(j+x<=9&&Chessman_Coordinate[i][j+x]>0)
            {
                To_Move[i][j+x]=10;
                break;
            }
            else break;
        }
        for(int x=1;x<=9;x++)
        {
            if(j-x>=0&&Chessman_Coordinate[i][j-x]==0) To_Move[i][j-x]=10;
            else  if(j-x>=0&&Chessman_Coordinate[i][j-x]>0)
            {
                To_Move[i][j-x]=10;
                break;
            }
            else break;
        }
        break;
    case -6:
        Is_Skip=false;
        for(int x=1;x<=8;x++)
        {
            if(i+x<=8&&Chessman_Coordinate[i+x][j]==0&&!Is_Skip) To_Move[i+x][j]=10;
            else  if(i+x<=8&&Chessman_Coordinate[i+x][j]!=0&&!Is_Skip)
            {
                Is_Skip=true;
            }
            else if(i+x<=8&&Chessman_Coordinate[i+x][j]>0&&Is_Skip)
            {
                To_Move[i+x][j]=10;
                break;
            }
        }
        Is_Skip=false;
        for(int x=1;x<=8;x++)
        {
            if(i-x>=0&&Chessman_Coordinate[i-x][j]==0&&!Is_Skip) To_Move[i-x][j]=10;
            else  if(i-x>=0&&Chessman_Coordinate[i-x][j]!=0&&!Is_Skip)
            {
                Is_Skip=true;
            }
            else if(i-x>=0&&Chessman_Coordinate[i-x][j]>0&&Is_Skip)
            {
                To_Move[i-x][j]=10;
                break;
            }
        }
        Is_Skip=false;
        for(int x=1;x<=9;x++)
        {
            if(j+x<=9&&Chessman_Coordinate[i][j+x]==0&&!Is_Skip) To_Move[i][j+x]=10;
            else  if(j+x<=9&&Chessman_Coordinate[i][j+x]!=0&&!Is_Skip)
            {
                Is_Skip=true;
            }
            else if(j+x<=9&&Chessman_Coordinate[i][j+x]>0&&Is_Skip)
            {
                To_Move[i][j+x]=10;
                break;
            }
        }
        Is_Skip=false;
        for(int x=1;x<=9;x++)
        {
            if(j-x>=0&&Chessman_Coordinate[i][j-x]==0&&!Is_Skip) To_Move[i][j-x]=10;
            else  if(j-x>=0&&Chessman_Coordinate[i][j-x]!=0&&!Is_Skip)
            {
                Is_Skip=true;
            }
            else if(j-x>=0&&Chessman_Coordinate[i][j-x]>0&&Is_Skip)
            {
                To_Move[i][j-x]=10;
                break;
            }
        }
        break;
    case -7:
        if(j>4)
        {
            To_Move[i][j-1]=10;
        }
        else
        {
            if(i-1>=0&&Chessman_Coordinate[i-1][j]>=0) To_Move[i-1][j]=10;
            if(i+1<=8&&Chessman_Coordinate[i+1][j]>=0) To_Move[i+1][j]=10;
            if(j-1>=0&&Chessman_Coordinate[i][j-1]>=0) To_Move[i][j-1]=10;
        }
        break;
    default:  break;
    }

}

void MainWindow::Eat_Chessman(int Eat_x, int Eat_y, int Eat_value, int Eaten_x, int Eaten_y, int Eaten_value)
{
    if(step==0) step++;
    else step=0;

    for(int i=0;i<9;i++){
        for(int j=0;j<10;j++){
            Regret[i][j][2] = Regret[i][j][1];
        }
    }
    for(int i=0;i<9;i++){
        for(int j=0;j<10;j++){
            Regret[i][j][1] = Regret[i][j][0];
        }
    }


    for(int i=0;i<9;i++){
        for(int j=0;j<10;j++){
            Regret[i][j][0] = Chessman_Coordinate[i][j];
        }
    }

    if(Chessman_Coordinate[Eat_x][Eat_y] > 0) died1 = Chessman_Coordinate[Eat_x][Eat_y];
    else if (Chessman_Coordinate[Eat_x][Eat_y] < 0) died2 = Chessman_Coordinate[Eat_x][Eat_y];
    Chessman_Coordinate[Eat_x][Eat_y]=0;
    Chessman_Coordinate[Eaten_x][Eaten_y]=Eat_value;


    Initialize_Move_Array();
    Is_Win();
    timing=0;
}

void MainWindow::Is_Win()
{
    Game_Is_Over=false;

    int a=0;
    int b=0;
    for(int x=0;x<9;x++)
    {
        for(int y=0;y<10;y++)
        {
          if(Chessman_Coordinate[x][y]==1) a++;
          if(Chessman_Coordinate[x][y]==-1) b++;
        }
    }
    QString Winer;
    if(a==0)
    {
        Game_Is_Over=true;
        Winer="red";
    }
    if(b==0)
    {
        Game_Is_Over=true;
        Winer="black";
    }

    if(Game_Is_Over==true) QMessageBox::information(this,"Finally",Winer+"  Win！",QMessageBox::Yes);
    std:baby.push_back(999);

}


void MainWindow::Start_Game_Slots()
{
    Clicked_X=0;
    Clicked_Y=0;
    step=0;
    timing=0;
    died1=0;
    died2=0;
    Regret_number = 0;
    Game_Is_Over=false;
    Start_Game->setText("restart");
    Initialize_Array();
    this->repaint();
}

void MainWindow::Special_Game_Slots()
{
    Clicked_X=0;
    Clicked_Y=0;
    step=0;
    timing=0;
    died1=0;
    died2=0;
    Regret_number = 0;
    Game_Is_Over=false;
    Special_Game->setText("restart");
    Special_Array();

    this->repaint();
}

void MainWindow::Regret_Game_Slots()
{

    if(step==0) step++;
    else step=0;
    //Regret_Game->setText("just can not");
    Initialize_Move_Array();

    for(int i=0;i<9;i++)
    {
        for(int j=0;j<10;j++)
        {
            Chessman_Coordinate[i][j]=Regret[i][j][Regret_number];
        }
    }
    Regret_number++;

    if(Regret_number == 3)
    {
        Regret_number=0;
    }
    this->repaint();
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPen pen(Qt::black, 5,Qt::SolidLine, Qt::RoundCap,Qt::RoundJoin);
    painter.setPen(pen);
    for(int i=0;i<10;i++)
    {
     painter.drawLine(50,50+i*100,850,50+i*100);
    }
    for(int i=0;i<9;i++)
    {
      painter.drawLine(50+100*i,50,50+100*i,450);
      painter.drawLine(50+100*i,550,50+100*i,950);
    }
    if(step==0)
    {
        QPen pen(Qt::black, 5,Qt::SolidLine, Qt::RoundCap,Qt::RoundJoin);
        painter.setPen(pen);
    }
    else
    {
        QPen pen(Qt::red, 5,Qt::SolidLine, Qt::RoundCap,Qt::RoundJoin);
        painter.setPen(pen);
    }


    for(int i=0;i<9;i++)
    {
        for(int j=0;j<10;j++)
        {
            if(To_Move[i][j]==10)
            {
                painter.drawRect(10+100*i,10+100*j,80,80);
            }
            switch (Chessman_Coordinate[i][j])
            {
            case 1:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/黑将.png"));  break;
            case 2:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/黑士.png"));  break;
            case 3:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/黑相.png"));  break;
            case 4:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/黑马.png"));  break;
            case 5:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/黑車.png"));  break;
            case 6:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/黑炮.png"));  break;
            case 7:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/黑兵.png"));  break;
            case -1:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/红帅.png"));  break;
            case -2:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/红士.png"));  break;
            case -3:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/红相.png"));  break;
            case -4:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/红马.png"));  break;
            case -5:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/红車.png"));  break;
            case -6:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/红炮.png"));  break;
            case -7:painter.drawImage(QRect(10+100*i,10+100*j,80,80),QImage(":/Chessman/img/红兵.png"));  break;
            default:       break;
            }
            if(To_Move[i][j]==10)
            {

                painter.drawRect(10+100*i,10+100*j,80,80);
            }
        }
    }
    painter.drawRect(10+100*Clicked_X,10+100*Clicked_Y,80,80);

    if(step==0) painter.drawRect(930,200,100,40);
    else if(step==1)
    {
        QPainter painter(this);
        QPen pen(Qt::red, 5,Qt::SolidLine, Qt::RoundCap,Qt::RoundJoin);
        painter.setPen(pen);
        painter.drawRect(930,600,100,40);
    }



}
